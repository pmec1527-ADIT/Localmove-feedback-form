FEEDBACK WEBSITE - QUICK START

1. Open public/index.html in Notepad and replace every PASTE_HERE
   with your Firebase config values (Firebase console > Project settings > Your apps).
2. In Firebase console > Firestore Database > Rules, publish the rules from the chat.
3. Open Command Prompt in this folder and run:
     npm install -g firebase-tools
     firebase login
     firebase use --add      (choose your project)
     firebase deploy
4. Open the Hosting URL it prints. Responses appear in Firestore > feedback.
